Application.$controller("TemplateController", ["$scope", function ($scope) {
    "use strict";
}]);
